# UNIVERSAL FLOW AI

Platform otomasi modular: setiap aplikasi adalah plugin, setiap plugin otomatis menjadi node 3D, dan semua node bisa disambung dalam satu workflow.

Repo ini adalah monorepo (Turborepo + pnpm):

| Paket | Isi | Status |
| --- | --- | --- |
| `packages/core-engine` | Plugin system, API connector, secret vault, node generator, workflow engine | Tahap 1, 69 tes |
| `apps/backend` | HTTP API, PostgreSQL, antrean job, worker, scheduler, OAuth, webhook, login pengguna | Tahap 2–3, 23 tes (termasuk end-to-end di PostgreSQL) |
| `apps/web` | Web app: login, Applications & Integrations, builder Custom API, Marketplace | Tahap 3, 10 unit tes + uji browser end-to-end |

Panduan: [`apps/backend/README.md`](apps/backend/README.md), [`apps/web/README.md`](apps/web/README.md).

## Isi core-engine

| Modul | Lokasi | Fungsi |
| --- | --- | --- |
| Plugin manifest | `src/manifest/` | Skema manifest, validasi lengkap (semua error dilaporkan sekaligus) |
| Kategori | `src/registry/category-registry.ts` | 30 kategori bawaan, admin bisa menambah/mengubah |
| Plugin registry | `src/registry/plugin-registry.ts` | Register, review, install, update (dengan diff izin), disable, uninstall, revoke, search, versi terkunci |
| Secret vault | `src/security/secret-store.ts` | Envelope encryption AES-256-GCM, kunci utama di KMS, terikat ke workspace |
| Pengaman | `src/security/` | Anti-SSRF (https saja, blokir IP privat/metadata, allowlist host), penyensoran secret |
| Universal API Connector | `src/connector/` | Auth (API key, Bearer, Basic, OAuth 2.0 + refresh), template request, response mapping, Test API |
| Node Generator | `src/nodes/node-generator.ts` | Manifest → definisi node 3D: port, panel konfigurasi, status koneksi, geometri |
| Workflow Engine | `src/workflow/` | DAG, paralel, kondisi, loop, delay, approval, retry + backoff, error port, history, webhook signature |

## Menjalankan

Butuh Node.js 20+ dan pnpm.

```bash
pnpm install
pnpm build
pnpm test
```

Atau hanya paket inti:

```bash
cd packages/core-engine
npx tsc -p tsconfig.json
npm test
```

## Contoh singkat

```ts
import {
  ENGINE_VERSION, createCategoryRegistry, createPluginRegistry, createSecretStore,
  createLocalKeyProvider, createInMemorySecretRepository, createApiConnector,
  createFetchHttpClient, createOAuthRefresher, generateNodeDefinitions,
} from '@universal-flow/core-engine';

const registry = createPluginRegistry({ categories: createCategoryRegistry(), engineVersion: ENGINE_VERSION });
const record = registry.register(myCustomAiManifest, { source: 'custom', ownerWorkspaceId: 'ws_1' });

const secrets = createSecretStore({
  keyProvider: createLocalKeyProvider(Buffer.from(process.env.MASTER_KEY_BASE64 ?? '', 'base64')),
  repository: createInMemorySecretRepository(),
});
const credential = await secrets.put({ workspaceId: 'ws_1', pluginId: record.manifest.id, authType: 'bearer', values: { token: '...' } });

const http = createFetchHttpClient();
const connector = createApiConnector({ http, secrets, refreshOAuth: createOAuthRefresher(http) });
const report = await connector.test({ manifest: record.manifest, actionKey: 'generate', input: { prompt: 'Halo' }, workspaceId: 'ws_1', credentialId: credential.id });
if (report.ok) registry.markTested(record.manifest.id, record.manifest.version);

const nodes = generateNodeDefinitions(record.manifest); // siap dirender di Spatial Studio
```

## Keputusan desain

- **Manifest adalah satu-satunya sumber kebenaran.** Node 3D, form konfigurasi, dan eksekusi dibaca dari manifest, jadi integrasi baru tidak perlu build ulang.
- **Versi plugin dikunci di workflow** (`pluginId@1.0.0`). Update plugin tidak mengubah workflow lama.
- **Kredensial hanya di backend.** Browser dan node 3D hanya melihat `credentialId`, nama field, dan status.
- **Ekspresi hanya path data** (`{{nodes.claude.output.text}}`), tanpa `eval` dan tanpa pemanggilan fungsi.
- **Runtime `native`** (kode handler) hanya untuk plugin resmi. Plugin komunitas bersifat deklaratif (HTTP) dan wajib lolos review.
- **Integrasi tanpa API resmi tidak diklaim penuh:** keterbatasan ditulis di `limitations` dan tampil di node serta Marketplace.

## Tahap berikutnya

1. Spatial Studio (React Three Fiber) yang merender `NodeDefinition` dari `GET /v1/nodes` dan menyimpan workflow lewat API yang sudah ada.
2. Plugin resmi pertama: Telegram, Claude, OpenAI, Google Drive, Google Sheets, YouTube, Facebook, Instagram.
3. Marketplace komunitas: sandbox kode kustom dan pemindaian keamanan otomatis.
4. Undangan anggota tim dan pengelolaan peran dari web app.
