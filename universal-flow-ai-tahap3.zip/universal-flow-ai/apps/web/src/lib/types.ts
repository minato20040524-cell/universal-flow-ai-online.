/** Shapes of the backend's JSON responses that the web app reads. */

export type Role = 'viewer' | 'editor' | 'admin' | 'owner';
export type AuthType = 'none' | 'api_key' | 'bearer' | 'basic' | 'oauth2';
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
export type PluginSource = 'official' | 'community' | 'custom';
export type VersionStatus = 'testing' | 'pending_review' | 'active' | 'rejected' | 'revoked';
export type JsonType = 'string' | 'number' | 'integer' | 'boolean' | 'object' | 'array' | 'null';

export type Session =
  | { authenticated: false }
  | {
      authenticated: true;
      user: { id: string; email: string; name: string; isPlatformAdmin: boolean };
      workspace: { id: string; name: string };
      role: Role;
      workspaces: { id: string; name: string; role: Role }[];
      csrfToken: string;
    };

export type SignedInSession = Extract<Session, { authenticated: true }>;

export type Category = { slug: string; name: string; icon: string | undefined; sortOrder: number; isSystem: boolean };

export type MarketplacePlugin = {
  id: string;
  name: string;
  provider: string;
  category: string;
  description: string | undefined;
  source: PluginSource;
  version: string;
  status: VersionStatus;
  icon: string | undefined;
  limitations: string[];
  registeredAt: number;
  ports: { inputs: number; outputs: number };
  installs: number;
  installed: boolean;
};

export type JsonSchema = {
  type?: JsonType;
  title?: string;
  description?: string;
  properties?: Record<string, JsonSchema>;
  required?: string[];
  enum?: (string | number | boolean | null)[];
  default?: unknown;
  maxLength?: number;
};

export type ManifestAction = {
  key: string;
  name: string;
  description: string | undefined;
  inputSchema: JsonSchema;
  outputSchema: JsonSchema;
  request: { method: HttpMethod; path: string } | undefined;
};

export type Manifest = {
  id: string;
  name: string;
  version: string;
  provider: string;
  category: string;
  description: string | undefined;
  runtime: 'http' | 'native';
  auth: { type: AuthType };
  baseUrl: string | undefined;
  permissions: string[];
  actions: ManifestAction[];
  limitations: string[];
  docs: string | undefined;
};

export type DataPort = { key: string; label: string; type: JsonType | 'any'; required: boolean; description: string | undefined };

export type ConfigField = {
  key: string;
  label: string;
  widget: 'text' | 'textarea' | 'number' | 'toggle' | 'select' | 'json';
  required: boolean;
  options: (string | number | boolean | null)[] | undefined;
  defaultValue: unknown;
  description: string | undefined;
};

export type NodeDefinition = {
  type: string;
  source: { kind: 'plugin'; pluginId: string; version: string; key: string; role: 'action' | 'trigger' } | { kind: 'builtin'; nodeKind: string };
  title: string;
  subtitle: string;
  color: string;
  category: string;
  dataInputs: DataPort[];
  dataOutputs: DataPort[];
  flowInputs: string[];
  flowOutputs: string[];
  configFields: ConfigField[];
  auth: { type: AuthType; required: boolean };
};

export type CredentialStatus = 'connected' | 'expired' | 'error';

export type Credential = {
  id: string;
  pluginId: string;
  authType: AuthType;
  status: CredentialStatus;
  fieldNames: string[];
  createdAt: number;
  expiresAt: number | undefined;
};

export type InstalledIntegration = {
  pluginId: string;
  name: string;
  provider: string;
  category: string;
  icon: string | undefined;
  source: PluginSource;
  version: string;
  status: VersionStatus;
  enabled: boolean;
  grantedPermissions: string[];
  limitations: string[];
  updateAvailable: string | undefined;
};

export type IntegrationDetail = {
  integration: InstalledIntegration;
  manifest: Manifest;
  permissions: { declared: string[]; granted: string[] };
  nodes: NodeDefinition[];
  credentials: Credential[];
};

export type PluginDetail = {
  manifest: Manifest;
  source: PluginSource;
  versions: { version: string; status: VersionStatus; registeredAt: number }[];
  nodes: NodeDefinition[];
};

export type Issue = { path: string; message: string };

export type TestReport = {
  ok: boolean;
  status: number | undefined;
  durationMs: number;
  request: { method: string; url: string; headers: Record<string, string> } | undefined;
  rawResponse: unknown;
  output: unknown;
  warnings: Issue[];
  error: { message: string; code: string } | undefined;
};

export type UpdatePreview = { from: string; to: string; permissions: { added: string[]; removed: string[] } };
