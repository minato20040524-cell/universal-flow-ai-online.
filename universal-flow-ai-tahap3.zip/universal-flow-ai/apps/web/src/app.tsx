import { useEffect, type ReactNode } from 'react';
import { resolveRoute } from './lib/router';
import { Logo } from './components/module';
import { Loading } from './components/ui';
import { LoginPage, SignupPage } from './features/auth/auth-pages';
import { CustomApiPage } from './features/custom-api/custom-api-page';
import { IntegrationDetailPage } from './features/integrations/integration-detail-page';
import { IntegrationsPage } from './features/integrations/integrations-page';
import { MarketplacePage } from './features/marketplace/marketplace-page';
import { PluginPage } from './features/marketplace/plugin-page';
import { goToSignIn, messageOf, useAppState } from './state/app-state';
import { Link, navigate, useLocation } from './state/navigation';

const ROUTES = [
  { name: 'login', pattern: '/login' },
  { name: 'signup', pattern: '/signup' },
  { name: 'integrations', pattern: '/integrations' },
  { name: 'custom-api', pattern: '/integrations/new' },
  { name: 'integration', pattern: '/integrations/:pluginId' },
  { name: 'marketplace', pattern: '/marketplace' },
  { name: 'plugin', pattern: '/marketplace/:pluginId' },
] as const;

const PUBLIC_ROUTES = new Set(['login', 'signup']);

const Wordmark = () => (
  <Link to="/integrations" className="wordmark" aria-label="Universal Flow AI home">
    <Logo />
    UNIVERSAL FLOW
  </Link>
);

const Shell = ({ children }: { children: ReactNode }) => {
  const { session, api, setSession, notify } = useAppState();
  if (!session?.authenticated) return null;

  const switchWorkspace = async (workspaceId: string) => {
    try {
      setSession(await api.switchWorkspace(workspaceId));
      navigate('/integrations');
    } catch (error) {
      notify(messageOf(error), 'error');
    }
  };

  const signOut = async () => {
    await api.logout().catch(() => undefined);
    setSession({ authenticated: false });
    navigate('/login', { replace: true });
  };

  return (
    <div className="shell">
      <aside className="rack">
        <Wordmark />
        <nav className="rack-nav" aria-label="Main">
          <Link to="/integrations">
            <span className="patch-point" aria-hidden="true" />
            Applications
          </Link>
          <Link to="/marketplace">
            <span className="patch-point" aria-hidden="true" />
            Marketplace
          </Link>
          <span aria-disabled="true" title="Workflows open in Spatial Studio, the next release">
            <span className="patch-point" aria-hidden="true" />
            Workflows
            <small>Soon</small>
          </span>
        </nav>
        <div className="rack-footer">
          <label>
            Workspace
            <select value={session.workspace.id} onChange={(event) => void switchWorkspace(event.target.value)}>
              {session.workspaces.map((workspace) => (
                <option key={workspace.id} value={workspace.id}>
                  {workspace.name}
                </option>
              ))}
            </select>
          </label>
          <span className="who">{session.user.name}</span>
          <span>{session.user.email}</span>
          <button type="button" onClick={() => void signOut()}>
            Sign out
          </button>
        </div>
      </aside>
      <main className="panel" id="main">
        {children}
      </main>
    </div>
  );
};

const NotFound = () => (
  <div className="empty">
    <h2>This page does not exist</h2>
    <p>The link may be old, or the app was removed from this workspace.</p>
    <div className="actions">
      <Link to="/integrations" className="btn">
        Go to applications
      </Link>
    </div>
  </div>
);

export const App = () => {
  const { session } = useAppState();
  const { path } = useLocation();
  const route = resolveRoute(ROUTES, path === '/' ? '/integrations' : path);
  const isPublic = route !== undefined && PUBLIC_ROUTES.has(route.name);

  useEffect(() => {
    if (!session) return;
    if (!session.authenticated && !isPublic) goToSignIn();
    if (session.authenticated && isPublic) navigate('/integrations', { replace: true });
  }, [session, isPublic]);

  useEffect(() => {
    const titles: Record<string, string> = { login: 'Sign in', signup: 'Create account', integrations: 'Applications', 'custom-api': 'Add a custom API', marketplace: 'Marketplace' };
    document.title = `${(route && titles[route.name]) ?? 'Universal Flow'} | UNIVERSAL FLOW AI`;
  }, [route?.name]);

  if (!session) return <Loading label="Starting" />;
  if (route?.name === 'login') return session.authenticated ? null : <LoginPage />;
  if (route?.name === 'signup') return session.authenticated ? null : <SignupPage />;
  if (!session.authenticated) return null;

  const page = (() => {
    switch (route?.name) {
      case 'integrations':
        return <IntegrationsPage />;
      case 'custom-api':
        return <CustomApiPage />;
      case 'integration':
        return <IntegrationDetailPage key={route.params.pluginId} pluginId={route.params.pluginId ?? ''} />;
      case 'marketplace':
        return <MarketplacePage />;
      case 'plugin':
        return <PluginPage key={route.params.pluginId} pluginId={route.params.pluginId ?? ''} />;
      default:
        return <NotFound />;
    }
  })();
  return <Shell key={session.workspace.id}>{page}</Shell>;
};
