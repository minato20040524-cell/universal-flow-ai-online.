// Bundles the web app into dist/: hashed JS and CSS under dist/assets and an index.html that loads them.
import { build, context } from 'esbuild';
import { copyFile, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { basename } from 'node:path';

const watch = process.argv.includes('--watch');
const production = !watch;
const outdir = 'dist';

const writeIndex = async (metafile) => {
  const outputs = Object.keys(metafile.outputs);
  const script = outputs.find((file) => file.endsWith('.js'));
  const style = outputs.find((file) => file.endsWith('.css'));
  if (!script || !style) throw new Error('Build produced no JS or CSS');
  const template = await readFile('index.html', 'utf8');
  const html = template
    .replace('<!-- styles -->', `<link rel="stylesheet" href="/assets/${basename(style)}">`)
    .replace('<!-- scripts -->', `<script type="module" src="/assets/${basename(script)}"></script>`);
  await writeFile(`${outdir}/index.html`, html);
  await copyFile('public/favicon.svg', `${outdir}/favicon.svg`);
};

const options = {
  entryPoints: { app: 'src/main.tsx' },
  bundle: true,
  outdir: `${outdir}/assets`,
  entryNames: '[name]-[hash]',
  format: 'esm',
  target: ['es2022', 'chrome110', 'firefox115', 'safari16'],
  jsx: 'automatic',
  minify: production,
  sourcemap: true,
  metafile: true,
  legalComments: 'none',
  define: { 'process.env.NODE_ENV': JSON.stringify(production ? 'production' : 'development') },
  logLevel: 'info',
  plugins: [{ name: 'index-html', setup: (builder) => builder.onEnd(async (result) => result.metafile && (await writeIndex(result.metafile))) }],
};

await rm(outdir, { recursive: true, force: true });
await mkdir(`${outdir}/assets`, { recursive: true });
if (watch) {
  const ctx = await context(options);
  await ctx.watch();
} else {
  await build(options);
}
