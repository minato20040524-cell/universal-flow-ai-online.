# @universal-flow/web

Web app UNIVERSAL FLOW AI: login, Applications & Integrations, builder Custom API, dan Marketplace. React 19 sebagai SPA, di-bundle esbuild, disajikan langsung oleh backend dari origin yang sama (cookie sesi tidak perlu CORS).

## Menjalankan

```bash
pnpm install
pnpm --filter @universal-flow/web build      # menghasilkan apps/web/dist
WEB_DIST_DIR=apps/web/dist node apps/backend/dist/src/main.js
```

Buka `PUBLIC_BASE_URL` di browser. Selama mengembangkan, `pnpm --filter @universal-flow/web dev` mem-bundle ulang setiap file berubah.

## Halaman

| Rute | Isi |
| --- | --- |
| `/login`, `/signup` | Masuk dan daftar; daftar langsung membuat workspace pertama |
| `/integrations` | Applications & Integrations: daftar modul terpasang, status, cari, filter kategori dan status, Import manifest |
| `/integrations/new` | Builder Custom API lima langkah dengan pratinjau modul yang langsung berubah |
| `/integrations/:id` | Connect account (API key, bearer, basic, OAuth 2.0), Test API, izin, node workflow, update, disable, uninstall |
| `/marketplace` | Featured, Popular, New, AI applications, Community, Built in this workspace; cari dan filter; Install dengan persetujuan izin; Publish a plugin |
| `/marketplace/:id` | Detail modul: aksi, izin, batasan, versi |

## Struktur

```
src/
  lib/          logika tanpa React (typecheck + unit test): API client, builder manifest, aturan tampilan, router
  state/        sesi, toast, navigasi, hook pemuat data
  components/   UI dasar dan komponen modul (faceplate, jack, tile)
  features/     auth, integrations, custom-api, marketplace
  styles.css    token desain dan semua gaya
e2e/ui.e2e.mjs  uji browser end-to-end + screenshot
```

## Arah desain

Sebuah *patch bay*: setiap aplikasi adalah modul dengan jack (port input di kiri, output di kanan), sama seperti nanti di Spatial Studio. Sidebar adalah rak gelap, panel berwarna aluminium, faceplate hampir putih. Warna kabel hanya dipakai untuk makna: hijau siap, kuning perlu tindakan, merah gagal. Huruf label memakai keluarga DIN (Bahnschrift di Windows, DIN Alternate di macOS) dengan cadangan sistem, tanpa font web.

## Keamanan

- Sesi di cookie `HttpOnly; SameSite=Lax` (dan `Secure` di HTTPS); token tidak pernah bisa dibaca JavaScript.
- Setiap perubahan mengirim header `x-csrf-token`; server juga menolak origin asing.
- CSP ketat dari backend: hanya skrip dan gaya milik sendiri, tanpa inline, tanpa iframe.
- Secret kredensial hanya dikirim sekali ke server; tidak pernah ditampilkan lagi.

## Pengujian

```bash
pnpm --filter @universal-flow/web test   # unit test logika (termasuk validasi silang dengan core)
# uji browser: jalankan server demo, lalu Playwright
node apps/backend/dist/test/support/demo-server.js &
pnpm --filter @universal-flow/web e2e
```

Uji browser melewati seluruh alur (daftar, pasang dari marketplace, buat MY CUSTOM AI, hubungkan akun, lulus Test API, OAuth Google Drive, disable/enable/uninstall, layar sempit, mode gelap, keluar), menyimpan screenshot di `e2e/screenshots/`, dan gagal bila ada error JavaScript atau pelanggaran CSP.
